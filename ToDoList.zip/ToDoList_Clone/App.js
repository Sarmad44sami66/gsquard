/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, { Component } from 'react';
import {
  SafeAreaView,
  StyleSheet,
  View,
  TouchableOpacity,
  Image,
  StatusBar,
  FlatList,
  Text,
  TextInput
} from 'react-native';

import assets from './assets'
import KeyboardAccessoryView from './components/KeyboardAccessoryView'
const inputAccessoryViewID = 'InputTextField'
class App extends Component {
  constructor(props) {
    super(props);

    this.state = {
      loading: false,
      todolistItems: [],
      inputText: ''
    }
  }

  changeStatus = (item, index) => {
    let todolistItemsTemp = this.state.todolistItems
    todolistItemsTemp[index].isChecked = !todolistItemsTemp[index].isChecked
    this.setState({ todolistItems: todolistItemsTemp })
  }

  addNewList = () => {
    const { inputText, todolistItems } = this.state
    if (inputText.length > 0) {
      let todolistItemsTemp = todolistItems
      todolistItemsTemp.push({ title: inputText, isChecked: false })
      this.setState({ todolistItems: todolistItemsTemp }, () => {
        this.focusField()
      })
    } else { this.focusField() }
  }

  focusField = () => {
    setTimeout(() => {
      if (this.textInputRef) this.textInputRef.focus()
    }, 50);
  }

  renderItem = ({ item, index }) => {
    return (
      <View style={styles.itemStyle}>
        <TouchableOpacity
          style={[styles.checkIconContainer, styles.shadowElevation]}
          onPress={() => { this.changeStatus(item, index) }}>
          {item.isChecked &&
            <Image
              style={styles.checkIconStyle}
              source={assets.checkIcon}
            />
          }
        </TouchableOpacity>
        <View style={styles.textContainer}>
          <Text style={{ textDecorationLine: item.isChecked ? 'line-through' : 'none' }}>{item.title}</Text>
        </View>
      </View>
    )
  }

  renderAddNewItem = () => {
    const { inputText } = this.state
    return (
      <View style={styles.itemStyle}>
        <TouchableOpacity
          disabled={true}
          style={[styles.checkIconContainer, styles.shadowElevation]}>
        </TouchableOpacity>
        <TextInput
          ref={ref => this.textInputRef = ref}
          value={inputText}
          style={styles.inputStyle}
          placeholder={'Enter New Item'}
          onChangeText={(text) => {
            this.setState({ inputText: text })
          }}
          onSubmitEditing={() => {
            this.addNewList()
          }}
          onFocus={() => {
            this.setState({ inputText: '' })
          }}
          inputAccessoryViewID={inputAccessoryViewID}
        />
      </View>
    )
  }

  render() {
    const { todolistItems } = this.state
    return (
      <>
        <StatusBar barStyle="dark-content" />
        <SafeAreaView>
          <Text style={styles.headingStyle}>{"TO DO LIST"}</Text>
          <FlatList
            showsVerticalScrollIndicator={false}
            showsHorizontalScrollIndicator={false}
            data={todolistItems}
            extraData={todolistItems}
            keyExtractor={(item, index) => index}
            numColumns={1}
            renderItem={this.renderItem}
          />
          {this.renderAddNewItem()}
          <KeyboardAccessoryView inputAccessoryViewID={inputAccessoryViewID} />
        </SafeAreaView>
      </>
    );
  }
};

const styles = StyleSheet.create({
  headingStyle: {
    fontSize: 20,
    alignSelf: 'center',
    marginVertical: 20
  },
  itemStyle: {
    flexDirection: 'row',
    width: '100%',
    minHeight: 60,
    alignItems: 'center',
  },
  checkIconContainer: {
    width: 30,
    height: 30,
    margin: 20,
    borderRadius: 5,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'white'
  },
  checkIconStyle: {
    width: 20,
    height: 20,
    resizeMode: 'contain',
    tintColor: 'green'
  },
  textContainer: {
    flex: 1,
    minHeight: 55,
    borderRadius: 10,
    marginRight: 35,
    justifyContent: 'center'
  },
  inputStyle: {
    flex: 1,
    backgroundColor: '#00000010',
    minHeight: 55,
    borderRadius: 10,
    paddingHorizontal: 15,
    marginRight: 20
  },
  shadowElevation: {
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.10,
    shadowRadius: 10.84,

    elevation: 5,
  },
});

export default App;
