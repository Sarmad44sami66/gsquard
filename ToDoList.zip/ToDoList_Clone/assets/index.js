export default {
    checkIcon: require('./check.png')
}